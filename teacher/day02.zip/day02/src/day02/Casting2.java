package day02;

public class Casting2 {
	public static void main(String[] args) {
		char data = 67;
		System.out.println(data + 7);
	}
}
