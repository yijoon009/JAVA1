package day02;

public class Variable {
	public static void main(String[] args) {
		int age = 10;
		float height = 10.77F;
		double weight = 10.77;
		char garde = 'A';
		String name = "ȫ�浿";
		
//		a = 80;
//		System.out.println(a + 8);
//		System.out.println(b);
//		System.out.println(c);
//		System.out.println(d);
//		System.out.println(e);
	}
}





