package day03;

import java.util.Scanner;

public class InputTest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("�̸� : ");
//		System.out.println(sc.next() + sc.next() + "��");
		System.out.println(sc.nextLine() + "��");
	}
}







