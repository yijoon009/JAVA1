package bank;

public class CU {
	public static void main(String[] args) {
		new ATM().useAtm();
	}
}
