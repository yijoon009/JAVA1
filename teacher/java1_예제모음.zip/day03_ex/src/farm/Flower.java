package farm;

public class Flower extends Plant{

	public Flower(int cnt, String name, long time) {
		super(cnt, name, time);
	}
}
