package day05;

public class Test {
	public static void main(String[] args) {
		String str1 = "ABC";
		String str2 = "ABC";
		
		String str3 = new String("ABC");
		String str4 = new String("ABC");
		
		System.out.println(str1 == str2);
		System.out.println(str3 == str4);
		System.out.println(str3.equals(str4));
		
	}
}
