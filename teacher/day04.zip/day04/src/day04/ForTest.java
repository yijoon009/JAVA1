package day04;

public class ForTest {
	public static void main(String[] args) {
//		for(int i = 0; i < 10; i=i+1) {
		for(int i = 0; i < 10; i++) {
			System.out.println(i + 1 + ".�ѵ���");
		}
	}
}
