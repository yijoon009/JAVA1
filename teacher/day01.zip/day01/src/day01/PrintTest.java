package day01;

public class PrintTest {
	public static void main(String[] args) {
		System.out.print("�ѵ���");
	}
}
