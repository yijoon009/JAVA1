package day07;

public class Test {
	public static void main(String[] args) {
		String data = "";
		
		data += "�ȳ�";
		System.out.println(data);
		
	}
}
