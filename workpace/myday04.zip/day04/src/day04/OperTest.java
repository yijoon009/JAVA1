package day04;

public class OperTest {
	public static void main(String[] args) {
		int data=10;
		//System.out.println(data++);
		System.out.println(++data);
		System.out.println(data);
		
	}
}
