package myday10;

public class Cat extends Animal{
	public Cat(String sound) {
		super(sound);
	}
	void wash() {
		System.out.println("�� ������");
	}
}
