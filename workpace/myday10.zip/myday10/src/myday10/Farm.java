package myday10;

public class Farm {
	public static void main(String[] args) {
		Dog �ǻ�=new Dog("�۸�");
		�ǻ�.getSound();
		
		
	}
}
