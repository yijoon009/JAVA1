package day02;

public class Casting2 {
	public static void main(String[] args) {
		char data=65;
		System.out.println(data);
		System.out.println(data+7);
		
	}
}
