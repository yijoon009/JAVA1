package day03;

public class OperTest {
	public static void main(String[] args) {
		boolean isTrue=10>9;
		
		System.out.println(isTrue);
		System.out.println(10>9);
		System.out.println(10<9);
		System.out.println(10<9&&10>9);
		System.out.println(10<9||10>9);
	}
}
