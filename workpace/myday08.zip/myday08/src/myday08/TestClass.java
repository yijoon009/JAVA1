package myday08;

public class TestClass {
	public static void main(String[] args) {
		int data=10;
		TestClass t=new TestClass();
		t.method(data);
		System.out.println(data);
	}
	void method(int num) {
		num=100;
	}
}
